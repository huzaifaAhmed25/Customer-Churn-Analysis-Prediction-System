"""
Churn Intelligence Dashboard - FINAL VERSION
Run: streamlit run app_FINAL.py
"""

import streamlit as st, pandas as pd, numpy as np
import plotly.express as px, plotly.graph_objects as go
from plotly.subplots import make_subplots
import warnings; warnings.filterwarnings('ignore')
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (confusion_matrix, roc_auc_score, roc_curve,
    accuracy_score, f1_score, precision_score, recall_score)

st.set_page_config(page_title="Customer Churn Analysis", page_icon="📡",
                   layout="wide", initial_sidebar_state="expanded")

# Colors
BG0='#050810'; BG1='#080d1a'; BG2='#0c1225'; BG3='#111830'
BORDER='#1a2240'; GRID='#111830'; MUTED='#4a5580'; WHITE='#e8eeff'
BLUE='#4f8ef7'; CYAN='#00d4ff'; PINK='#ff4d6d'; GREEN='#00e5a0'
AMBER='#ffb340'; PURPLE='#a855f7'; TEAL='#1abc9c'

IMG_HERO    = "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1400&q=80"
IMG_NETWORK = "https://images.unsplash.com/photo-1639322537228-f710d846310a?w=800&q=80"
IMG_TEAM    = "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&q=80"
IMG_CHART   = "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80"

st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
html,body,[data-testid="stAppViewContainer"]{{
    font-family:'Space Grotesk',sans-serif!important;
}}
[data-testid="stAppViewContainer"]{{background:{BG0};background-image:radial-gradient(ellipse 80% 50% at 50% -20%,rgba(79,142,247,.12),transparent)}}
[data-testid="stHeader"]{{background:transparent}}
[data-testid="stSidebar"]{{background:{BG1};border-right:1px solid {BORDER}}}
#MainMenu,footer{{visibility:hidden}}
.block-container{{padding:0 2rem 3rem}}
div[data-testid="stRadio"] label{{background:transparent!important;border:1px solid transparent!important;border-radius:10px!important;padding:9px 12px!important;color:{MUTED}!important;font-size:.88rem!important;transition:all .18s}}
div[data-testid="stRadio"] label:hover{{background:rgba(79,142,247,.08)!important;color:{WHITE}!important}}
div[data-testid="stRadio"] label[data-checked="true"]{{background:rgba(79,142,247,.15)!important;color:{BLUE}!important;font-weight:500!important}}
.card{{background:{BG2};border:1px solid {BORDER};border-radius:16px;padding:1.2rem 1.4rem;position:relative;overflow:hidden}}
.card::before{{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--ac,{BLUE})}}
.card-icon{{width:34px;height:34px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1rem;margin-bottom:.7rem;background:rgba(79,142,247,.1)}}
.card-label{{font-size:.65rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:{MUTED};margin-bottom:.3rem}}
.card-value{{font-size:1.8rem;font-weight:700;color:{WHITE};font-family:'JetBrains Mono',monospace;line-height:1}}
.card-sub{{font-size:.73rem;color:{MUTED};margin-top:.3rem}}
.hero{{position:relative;border-radius:20px;overflow:hidden;margin-bottom:1.6rem;border:1px solid {BORDER}}}
.hero-img{{width:100%;height:210px;object-fit:cover;object-position:center 40%;display:block;filter:brightness(.38) saturate(1.2)}}
.hero-overlay{{position:absolute;inset:0;background:linear-gradient(90deg,rgba(5,8,16,.95) 0%,rgba(5,8,16,.5) 60%,transparent 100%);display:flex;align-items:center;padding:2rem 2.4rem;gap:2rem}}
.hero-tag{{display:inline-block;background:rgba(79,142,247,.18);border:1px solid rgba(79,142,247,.35);border-radius:20px;padding:3px 12px;font-size:.68rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:{BLUE};margin-bottom:.6rem}}
.hero-title{{font-size:1.9rem;font-weight:700;color:{WHITE};line-height:1.15;margin:0 0 .4rem}}
.hero-sub{{font-size:.85rem;color:rgba(232,238,255,.5)}}
.hero-stat{{display:flex;flex-direction:column;align-items:center;padding:0 1.2rem;border-left:1px solid rgba(255,255,255,.1)}}
.hero-stat-value{{font-size:1.6rem;font-weight:700;color:{WHITE};font-family:'JetBrains Mono',monospace}}
.hero-stat-label{{font-size:.68rem;color:rgba(255,255,255,.4);margin-top:2px}}
.sec-hdr{{display:flex;align-items:center;gap:10px;margin:1.6rem 0 .8rem}}
.sec-line{{flex:1;height:1px;background:linear-gradient(90deg,{BORDER},transparent)}}
.sec-text{{font-size:.68rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:{MUTED};white-space:nowrap}}
.img-panel{{border-radius:14px;overflow:hidden;border:1px solid {BORDER};position:relative}}
.img-panel img{{width:100%;height:170px;object-fit:cover;display:block;filter:brightness(.5) saturate(1.3)}}
.img-caption{{position:absolute;bottom:0;left:0;right:0;padding:.6rem 1rem;background:linear-gradient(transparent,rgba(5,8,16,.9));font-size:.78rem;color:{WHITE};font-weight:500}}
.insight-strip{{background:{BG2};border:1px solid {BORDER};border-radius:14px;padding:1rem 1.6rem;margin-top:1rem;display:flex;gap:2.5rem;flex-wrap:wrap;align-items:center}}
.isl{{font-size:.65rem;color:{MUTED};text-transform:uppercase;letter-spacing:.1em;font-weight:600}}
.isv{{font-size:.9rem;color:{WHITE};margin-top:3px;font-family:'JetBrains Mono',monospace}}
.result-card{{background:{BG2};border:1px solid {BORDER};border-radius:20px;padding:2rem 1.8rem;text-align:center}}
.info-row{{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid {BORDER};font-size:.84rem}}
div[data-testid="stFormSubmitButton"] button{{background:linear-gradient(135deg,{BLUE},{PURPLE})!important;color:#fff!important;border:none!important;border-radius:12px!important;font-weight:600!important;width:100%!important}}
button[data-baseweb="tab"]{{color:{MUTED}!important;font-size:.85rem!important}}
button[data-baseweb="tab"][aria-selected="true"]{{color:{BLUE}!important}}
[data-testid="stTabs"] [data-baseweb="tab-highlight"]{{background:{BLUE}!important}}



</style>

""", unsafe_allow_html=True)

# ── Single safe layout function — NO dict spreading ────────────────────────────
def fig_theme(fig, title='', h=360, xt='', yt='', legend=True,
              barmode=None, hide_colorscale=True, cat_order=None):
    """Apply consistent dark theme. Safe: builds one dict, calls update_layout once."""
    yaxis_cfg = dict(gridcolor=GRID, linecolor=BORDER,
                     tickfont=dict(color=MUTED),
                     title=dict(text=yt, font=dict(color=MUTED)))
    if cat_order:
        yaxis_cfg['categoryorder'] = cat_order

    layout = dict(
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor=BG2,
        title=dict(text=title, font=dict(color=WHITE, size=13), x=0,
                   pad=dict(l=4)),
        font=dict(color=MUTED, family='Space Grotesk', size=11),
        xaxis=dict(gridcolor=GRID, linecolor=BORDER,
                   tickfont=dict(color=MUTED),
                   title=dict(text=xt, font=dict(color=MUTED))),
        yaxis=yaxis_cfg,
        margin=dict(l=8, r=8, t=42, b=8),
        legend=dict(bgcolor='rgba(0,0,0,0)', bordercolor=BORDER,
                    font=dict(color=MUTED)),
        height=h,
        showlegend=legend,
        coloraxis_showscale=not hide_colorscale,
    )
    if barmode:
        layout['barmode'] = barmode
    fig.update_layout(**layout)   # ← only ONE call, ONE dict, zero conflicts
    fig.update_traces(hoverlabel=dict(bgcolor=BG3, bordercolor=BORDER,
                                      font=dict(color=WHITE)))
    return fig

def sec(label):
    st.markdown(f'<div class="sec-hdr"><span class="sec-text">{label}</span>'
                f'<div class="sec-line"></div></div>', unsafe_allow_html=True)

def kpi_card(label, value, sub='', accent=BLUE, icon=''):
    return (f'<div class="card" style="--ac:{accent}">'
            f'<div class="card-icon">{icon}</div>'
            f'<div class="card-label">{label}</div>'
            f'<div class="card-value">{value}</div>'
            + (f'<div class="card-sub">{sub}</div>' if sub else '')
            + '</div>')

def hero(img, tag, title, subtitle, stats=None):
    stats_html = ''
    if stats:
        for val, lbl, clr in stats:
            stats_html += (f'<div class="hero-stat">'
                           f'<div class="hero-stat-value" style="color:{clr}">{val}</div>'
                           f'<div class="hero-stat-label">{lbl}</div></div>')
    st.markdown(f"""
    <div class="hero" style="margin-top:1.4rem">
        <img class="hero-img" src="{img}">
        <div class="hero-overlay">
            <div style="flex:1">
                <div class="hero-tag">{tag}</div>
                <div class="hero-title">{title}</div>
                <div class="hero-sub">{subtitle}</div>
            </div>
            <div style="display:flex">{stats_html}</div>
        </div>
    </div>""", unsafe_allow_html=True)

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"""
    <div style="padding:1.4rem 1rem 1rem;border-bottom:1px solid {BORDER};margin-bottom:.8rem">
        <div style="display:flex;align-items:center;gap:10px">
            <div style="width:32px;height:32px;border-radius:9px;
                        background:linear-gradient(135deg,{BLUE},{PURPLE});
                        display:flex;align-items:center;justify-content:center;
                        font-size:1rem">📡</div>
            <div>
                <div style="font-size:.9rem;font-weight:700;color:{WHITE}">Churn Analysis</div>
                <div style="font-size:.65rem;color:{MUTED}">ML Dashboard</div>
            </div>
        </div>
    </div>""", unsafe_allow_html=True)

    uploaded = st.file_uploader("", type=["xlsx","csv"], label_visibility="collapsed")

    st.markdown(f'<div style="padding:.2rem 1rem;font-size:.65rem;font-weight:600;'
                f'letter-spacing:.12em;text-transform:uppercase;color:{MUTED};'
                f'margin-top:.6rem">Navigation</div>', unsafe_allow_html=True)

    page = st.radio("nav", ["🏠  Overview","📊  Explore Data",
                             "🤖  Model Results","🔮  Predict Customer"],
                    label_visibility="collapsed")

    if uploaded:
        st.markdown(f"""
        <div style="margin:.8rem .5rem 0;background:{BG3};border:1px solid {BORDER};
                    border-radius:10px;padding:9px 11px">
            <div style="font-size:.62rem;color:{BLUE};font-weight:700;
                        text-transform:uppercase;letter-spacing:.1em">Loaded</div>
            <div style="font-size:.78rem;color:{WHITE};margin-top:2px;
                        word-break:break-all">{uploaded.name}</div>
        </div>""", unsafe_allow_html=True)

# ── No file ────────────────────────────────────────────────────────────────────
if not uploaded:
    hero(IMG_HERO, "📡 Telecom Analytics",
         "Customer Churn<br>Analysis",
         "Upload your Telco dataset to uncover churn patterns,<br>"
         "train ML models, and predict individual risk.")
    c1,c2,c3 = st.columns(3)
    for col, img, cap in [
        (c1, IMG_NETWORK, "📊 EDA & Pattern Discovery"),
        (c2, IMG_CHART,   "🤖 ML Model Evaluation"),
        (c3, IMG_TEAM,    "🔮 Live Churn Prediction"),
    ]:
        col.markdown(f'<div class="img-panel"><img src="{img}">'
                     f'<div class="img-caption">{cap}</div></div>',
                     unsafe_allow_html=True)
    st.markdown(f"<div style='text-align:center;margin-top:1.2rem;color:{MUTED};"
                "font-size:.88rem'>↑ Upload your dataset from the sidebar</div>",
                unsafe_allow_html=True)
    st.stop()

# ── Load & train ───────────────────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def load_data(fb, fn):
    import io
    df = pd.read_excel(io.BytesIO(fb)) if fn.endswith('.xlsx') \
         else pd.read_csv(io.BytesIO(fb))
    df['Total Charges'] = pd.to_numeric(df['Total Charges'], errors='coerce')
    df['Total Charges'].fillna(df['Total Charges'].median(), inplace=True)
    return df

@st.cache_resource(show_spinner=False)
def train_models(fb, fn):
    import io
    df = pd.read_excel(io.BytesIO(fb)) if fn.endswith('.xlsx') \
         else pd.read_csv(io.BytesIO(fb))
    df['Total Charges'] = pd.to_numeric(df['Total Charges'], errors='coerce')
    df['Total Charges'].fillna(df['Total Charges'].median(), inplace=True)
    drop = [c for c in ['CustomerID','Count','Country','State','City','Zip Code',
            'Lat Long','Latitude','Longitude','Churn Label',
            'Churn Score','CLTV','Churn Reason'] if c in df.columns]
    dm = df.drop(columns=drop).copy()
    encs = {}
    for col in dm.select_dtypes(include='object').columns:
        le = LabelEncoder()
        dm[col] = le.fit_transform(dm[col].astype(str))
        encs[col] = le
    dm.fillna(dm.median(numeric_only=True), inplace=True)
    X = dm.drop(columns='Churn Value'); y = dm['Churn Value']
    Xtr,Xte,ytr,yte = train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
    sc = StandardScaler()
    Xtr_sc = sc.fit_transform(Xtr); Xte_sc = sc.transform(Xte)
    lr = LogisticRegression(max_iter=1000,random_state=42,class_weight='balanced')
    lr.fit(Xtr_sc, ytr)
    rf = RandomForestClassifier(n_estimators=200,max_depth=12,random_state=42,
                                class_weight='balanced',n_jobs=-1)
    rf.fit(Xtr, ytr)
    return lr,rf,sc,X,Xte,yte,Xte_sc,encs

fb = uploaded.getvalue(); fn = uploaded.name
with st.spinner("⚡ Training models — cached after first run…"):
    df = load_data(fb, fn)
    lr,rf,sc,X,Xte,yte,Xte_sc,encs = train_models(fb, fn)

lr_pred=lr.predict(Xte_sc); lr_prob=lr.predict_proba(Xte_sc)[:,1]
rf_pred=rf.predict(Xte);    rf_prob=rf.predict_proba(Xte)[:,1]
cr = df['Churn Value'].mean()*100
churned = int(df['Churn Value'].sum())

# ══════════════════════════════════════════════════════════════════════════════
# OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════
if page == "🏠  Overview":
    hero(IMG_HERO, "📡 IBM Telco Dataset",
         "Customer Churn Overview",
         f"{len(df):,} customers analysed across {df.shape[1]} features",
         stats=[(f"{cr:.1f}%","Churn Rate",PINK),
                (f"{roc_auc_score(yte,rf_prob):.3f}","Best AUC",GREEN),
                (f"{churned:,}","Churned",WHITE)])

    c1,c2,c3,c4,c5,c6 = st.columns(6)
    for col,lbl,val,sub,ac,icon in [
        (c1,"Churn Rate",  f"{cr:.1f}%",       f"{churned:,} lost",        PINK,  "📉"),
        (c2,"Churned",     f"{churned:,}",      "customers",                PINK,  "❌"),
        (c3,"Retained",    f"{len(df)-churned:,}","customers",              GREEN, "✅"),
        (c4,"Avg Tenure",  f"{df['Tenure Months'].mean():.0f} mo","avg",    BLUE,  "📅"),
        (c5,"Avg Bill",    f"${df['Monthly Charges'].mean():.0f}","monthly", PURPLE,"💳"),
        (c6,"Best AUC",    f"{roc_auc_score(yte,rf_prob):.3f}","RF",        CYAN,  "🎯"),
    ]:
        col.markdown(kpi_card(lbl,val,sub,ac,icon), unsafe_allow_html=True)

    sec("Churn Breakdown")
    ca,cb = st.columns(2)
    with ca:
        vc = df['Churn Label'].value_counts()
        fig = go.Figure(go.Pie(labels=vc.index, values=vc.values, hole=.58,
            marker=dict(colors=[BLUE,PINK], line=dict(color=BG0,width=3)),
            textfont=dict(color=WHITE,size=13)))
        fig.add_annotation(text=f"<b>{cr:.1f}%</b><br>churn",
                           x=.5,y=.5,showarrow=False,font=dict(size=16,color=WHITE))
        fig_theme(fig, title="Churn vs Retained", h=320)
        st.plotly_chart(fig, use_container_width=True)
    with cb:
        ct=(df.groupby('Contract')['Churn Value'].mean()*100).reset_index()
        ct.columns=['Contract','Rate']; ct=ct.sort_values('Rate',ascending=False)
        fig=px.bar(ct,x='Contract',y='Rate',color='Rate',
                   color_continuous_scale=[[0,BLUE],[.4,AMBER],[1,PINK]],
                   text=ct['Rate'].apply(lambda v:f'{v:.1f}%'))
        fig.update_traces(textposition='outside',textfont=dict(color=WHITE),
                          marker_line_color=BG0,marker_line_width=2)
        fig_theme(fig,title="Churn by Contract",h=320,yt="%",hide_colorscale=True)
        st.plotly_chart(fig, use_container_width=True)

    sec("Tenure & Billing")
    cc,cd = st.columns(2)
    with cc:
        fig=px.histogram(df,x='Tenure Months',color='Churn Label',nbins=36,
                         barmode='overlay',opacity=.76,
                         color_discrete_map={'No':BLUE,'Yes':PINK})
        fig_theme(fig,title="Tenure Distribution",h=300,xt='Months',
                  yt='Customers',barmode='overlay')
        st.plotly_chart(fig, use_container_width=True)
    with cd:
        fig=px.violin(df,x='Churn Label',y='Monthly Charges',color='Churn Label',
                      box=True,points=False,
                      color_discrete_map={'No':BLUE,'Yes':PINK})
        fig_theme(fig,title="Monthly Charges by Churn",h=300,yt='$/month',legend=False)
        st.plotly_chart(fig, use_container_width=True)

    top_reason = df['Churn Reason'].value_counts().index[0] \
                 if 'Churn Reason' in df.columns else 'N/A'
    fiber_c  = df[df['Internet Service']=='Fiber optic']['Churn Value'].mean()*100
    mtm_c    = df[df['Contract']=='Month-to-month']['Churn Value'].mean()*100
    senior_c = df[df['Senior Citizen']=='Yes']['Churn Value'].mean()*100

    sec("Key Insights")
    im1,im2 = st.columns([3,1])
    with im1:
        st.markdown(f"""
        <div class="insight-strip">
            <div><div class="isl">Top churn reason</div>
                 <div class="isv" style="color:{WHITE};font-family:'Space Grotesk',sans-serif">
                     {top_reason}</div></div>
            <div><div class="isl">Fiber optic churn</div>
                 <div class="isv" style="color:{PINK}">{fiber_c:.1f}%</div></div>
            <div><div class="isl">Month-to-month</div>
                 <div class="isv" style="color:{PINK}">{mtm_c:.1f}%</div></div>
            <div><div class="isl">Senior citizens</div>
                 <div class="isv" style="color:{AMBER}">{senior_c:.1f}%</div></div>
        </div>""", unsafe_allow_html=True)
    with im2:
        st.markdown(f'<div class="img-panel" style="margin-top:1rem">'
                    f'<img src="{IMG_TEAM}" style="height:120px">'
                    f'<div class="img-caption">Customer behaviour</div></div>',
                    unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# EXPLORE DATA
# ══════════════════════════════════════════════════════════════════════════════
elif page == "📊  Explore Data":
    hero(IMG_CHART,"📊 EDA","Explore Data",
         f"{len(df):,} records · {df.shape[1]} features")

    tab1,tab2,tab3,tab4 = st.tabs(
        ["📋 Dataset","📈 Feature Analysis","🔗 Correlations","❓ Churn Reasons"])

    with tab1:
        ci,cp = st.columns([1,2])
        with ci:
            sec("Stats")
            for k,v in {"Rows":f"{len(df):,}","Columns":df.shape[1],
                "Churn Rate":f"{cr:.2f}%","Avg Tenure":f"{df['Tenure Months'].mean():.1f} mo",
                "Avg Monthly":f"${df['Monthly Charges'].mean():.2f}",
                "Missing":"0 (cleaned)"}.items():
                st.markdown(f'<div class="info-row">'
                            f'<span style="color:{MUTED}">{k}</span>'
                            f'<span style="color:{WHITE};font-weight:500">{v}</span>'
                            f'</div>', unsafe_allow_html=True)
        with cp:
            sec("Preview")
            st.dataframe(df.head(50), use_container_width=True, height=310)

    with tab2:
        cats=[c for c in ['Internet Service','Contract','Payment Method','Gender',
              'Senior Citizen','Partner','Dependents','Paperless Billing',
              'Tech Support','Online Security'] if c in df.columns]
        sel=st.selectbox("Feature",cats)
        c1,c2=st.columns(2)
        with c1:
            vc=df[sel].value_counts().reset_index(); vc.columns=[sel,'Count']
            fig=px.bar(vc,x=sel,y='Count',color='Count',
                       color_continuous_scale=[[0,BLUE],[1,PURPLE]])
            fig.update_traces(marker_line_color=BG0,marker_line_width=1.5)
            fig_theme(fig,title=f"{sel} — count",hide_colorscale=True)
            st.plotly_chart(fig, use_container_width=True)
        with c2:
            cr2=(df.groupby(sel)['Churn Value'].mean()*100).reset_index()
            cr2.columns=[sel,'Rate']; cr2=cr2.sort_values('Rate',ascending=False)
            fig=px.bar(cr2,x=sel,y='Rate',color='Rate',
                       color_continuous_scale=[[0,BLUE],[.5,AMBER],[1,PINK]],
                       text=cr2['Rate'].apply(lambda v:f'{v:.1f}%'))
            fig.update_traces(textposition='outside',textfont=dict(color=WHITE),
                              marker_line_color=BG0,marker_line_width=1.5)
            fig_theme(fig,title=f"{sel} — churn rate",yt='%',hide_colorscale=True)
            st.plotly_chart(fig, use_container_width=True)

        sec("Numeric Distributions")
        fig=make_subplots(1,3,subplot_titles=['Tenure (mo)','Monthly ($)','Total ($)'])
        for i,col in enumerate(['Tenure Months','Monthly Charges','Total Charges'],1):
            for lbl,clr in [('No',BLUE),('Yes',PINK)]:
                s=df[df['Churn Label']==lbl][col]
                fig.add_trace(go.Histogram(x=s,name=lbl,marker_color=clr,
                                           opacity=.75,showlegend=(i==1),
                                           nbinsx=28),row=1,col=i)
        fig_theme(fig,barmode='overlay',h=290)
        st.plotly_chart(fig, use_container_width=True)

    with tab3:
        num=[c for c in ['Tenure Months','Monthly Charges','Total Charges',
                          'Churn Value','Churn Score','CLTV'] if c in df.columns]
        fig=px.imshow(df[num].corr(),text_auto='.2f',aspect='auto',
                      color_continuous_scale=[[0,PINK],[.5,BG3],[1,BLUE]],
                      zmin=-1,zmax=1)
        fig_theme(fig,title="Correlation Heatmap",h=400,hide_colorscale=False)
        fig.update_traces(textfont=dict(size=13,color=WHITE))
        st.plotly_chart(fig, use_container_width=True)

        sec("Scatter Explorer")
        n1,n2=st.columns(2)
        xax=n1.selectbox("X axis",num,0); yax=n2.selectbox("Y axis",num,1)
        fig=px.scatter(df.sample(min(2500,len(df)),random_state=1),
                       x=xax,y=yax,color='Churn Label',opacity=.55,
                       color_discrete_map={'No':BLUE,'Yes':PINK})
        fig_theme(fig,title=f"{xax} vs {yax}")
        st.plotly_chart(fig, use_container_width=True)

    with tab4:
        if 'Churn Reason' in df.columns:
            reasons=df['Churn Reason'].value_counts().head(15).reset_index()
            reasons.columns=['Reason','Count']
            fig=px.bar(reasons,x='Count',y='Reason',orientation='h',color='Count',
                       color_continuous_scale=[[0,PURPLE],[.5,PINK],[1,'#ff6b35']])
            fig.update_traces(marker_line_color=BG0,marker_line_width=1)
            fig_theme(fig,title="Top 15 Churn Reasons",h=480,
                      hide_colorscale=True,cat_order='total ascending')
            st.plotly_chart(fig, use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
# MODEL RESULTS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🤖  Model Results":
    hero(IMG_NETWORK,"🤖 Machine Learning","Model Results",
         "Logistic Regression vs Random Forest",
         stats=[(f"{accuracy_score(yte,lr_pred)*100:.1f}%","LR Accuracy",BLUE),
                (f"{accuracy_score(yte,rf_pred)*100:.1f}%","RF Accuracy",GREEN)])

    m1,m2=st.columns(2)
    for col,name,pred,prob,clr,icon in [
        (m1,'Logistic Regression',lr_pred,lr_prob,BLUE,'📐'),
        (m2,'Random Forest',rf_pred,rf_prob,GREEN,'🌲'),
    ]:
        with col:
            st.markdown(f'<div style="background:{BG2};border:1px solid {BORDER};'
                        f'border-radius:16px;padding:1.2rem;border-top:2px solid {clr}">'
                        f'<div style="font-size:.9rem;font-weight:600;color:{clr};'
                        f'margin-bottom:.8rem">{icon} {name}</div>'
                        f'<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px">',
                        unsafe_allow_html=True)
            for lbl,val in [
                ('Accuracy',accuracy_score(yte,pred)*100),
                ('Precision',precision_score(yte,pred)*100),
                ('Recall',recall_score(yte,pred)*100),
                ('F1',f1_score(yte,pred)*100),
                ('AUC-ROC',roc_auc_score(yte,prob)*100),
            ]:
                col.markdown(
                    f'<div style="background:{BG3};border-radius:9px;padding:9px 6px;'
                    f'text-align:center">'
                    f'<div style="font-size:.58rem;color:{MUTED};text-transform:uppercase;'
                    f'letter-spacing:.08em;font-weight:600">{lbl}</div>'
                    f'<div style="font-size:1.1rem;font-weight:700;color:{clr};'
                    f'font-family:JetBrains Mono,monospace;margin-top:3px">{val:.1f}%</div>'
                    f'</div>', unsafe_allow_html=True)
            col.markdown('</div></div>', unsafe_allow_html=True)

    sec("")
    t1,t2,t3=st.tabs(["📉 ROC Curves","🔲 Confusion Matrices","🌟 Feature Importance"])

    with t1:
        fig=go.Figure()
        for name,prob,clr in [('Logistic Regression',lr_prob,BLUE),
                                ('Random Forest',rf_prob,GREEN)]:
            fpr,tpr,_=roc_curve(yte,prob); auc=roc_auc_score(yte,prob)
            fig.add_trace(go.Scatter(x=fpr,y=tpr,mode='lines',
                name=f'{name}  AUC={auc:.3f}',line=dict(color=clr,width=2.5)))
        fig.add_trace(go.Scatter(x=[0,1],y=[0,1],mode='lines',name='Baseline',
            line=dict(color=MUTED,width=1.2,dash='dash')))
        fig_theme(fig,title="ROC Curve Comparison",h=420,
                  xt='False Positive Rate',yt='True Positive Rate')
        st.plotly_chart(fig, use_container_width=True)

    with t2:
        cc1,cc2=st.columns(2)
        for col,name,pred,clr in [(cc1,'Logistic Regression',lr_pred,BLUE),
                                   (cc2,'Random Forest',rf_pred,GREEN)]:
            with col:
                cm=confusion_matrix(yte,pred)
                fig=px.imshow(cm,text_auto=True,aspect='auto',
                              x=['No Churn','Churn'],y=['No Churn','Churn'],
                              color_continuous_scale=[[0,BG2],[1,clr]],title=name)
                fig_theme(fig,h=320)
                fig.update_traces(textfont=dict(size=16,color=WHITE))
                st.plotly_chart(fig, use_container_width=True)

    with t3:
        fi=pd.Series(rf.feature_importances_,index=X.columns).sort_values()
        fig=go.Figure(go.Bar(x=fi.values,y=fi.index,orientation='h',
            marker_color=[PINK if v>fi.median() else BLUE for v in fi.values],
            marker_line_color=BG0,marker_line_width=1))
        fig_theme(fig,title="Feature Importances — Random Forest",h=520,xt='Score')
        st.plotly_chart(fig, use_container_width=True)

        top5=pd.Series(rf.feature_importances_,index=X.columns)\
               .sort_values(ascending=False).head(5)
        sec("Top 5 Churn Predictors")
        for i,(pc,(feat,val)) in enumerate(zip(st.columns(5),top5.items())):
            pc.markdown(
                f'<div style="background:{BG2};border:1px solid {BORDER};'
                f'border-radius:12px;padding:13px;text-align:center;'
                f'border-top:2px solid {BLUE}">'
                f'<div style="font-size:.6rem;color:{MUTED};font-weight:700">#{i+1}</div>'
                f'<div style="font-size:.8rem;color:{WHITE};font-weight:500;'
                f'margin:.3rem 0;line-height:1.3">{feat}</div>'
                f'<div style="font-size:.8rem;color:{BLUE};'
                f'font-family:JetBrains Mono,monospace">{val*100:.1f}%</div>'
                f'</div>', unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# PREDICT CUSTOMER
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🔮  Predict Customer":
    hero(IMG_TEAM,"🔮 Prediction Engine","Predict Customer",
         "Fill in details to get an ensemble churn probability score")

    with st.form("pred_form"):
        c1,c2,c3=st.columns(3)
        with c1:
            st.markdown(f'<div style="font-size:.68rem;color:{MUTED};font-weight:700;'
                        'text-transform:uppercase;letter-spacing:.1em;margin-bottom:.4rem">'
                        'Demographics</div>', unsafe_allow_html=True)
            gender=st.selectbox("Gender",["Male","Female"])
            senior=st.selectbox("Senior Citizen",["No","Yes"])
            partner=st.selectbox("Partner",["Yes","No"])
            dependents=st.selectbox("Dependents",["No","Yes"])
            tenure=st.slider("Tenure (months)",0,72,24)
            phone=st.selectbox("Phone Service",["Yes","No"])
        with c2:
            st.markdown(f'<div style="font-size:.68rem;color:{MUTED};font-weight:700;'
                        'text-transform:uppercase;letter-spacing:.1em;margin-bottom:.4rem">'
                        'Services</div>', unsafe_allow_html=True)
            multiline=st.selectbox("Multiple Lines",["No","Yes","No phone service"])
            internet=st.selectbox("Internet Service",["Fiber optic","DSL","No"])
            online_sec=st.selectbox("Online Security",["No","Yes","No internet service"])
            online_bk=st.selectbox("Online Backup",["Yes","No","No internet service"])
            dev_prot=st.selectbox("Device Protection",["No","Yes","No internet service"])
            tech_sup=st.selectbox("Tech Support",["No","Yes","No internet service"])
        with c3:
            st.markdown(f'<div style="font-size:.68rem;color:{MUTED};font-weight:700;'
                        'text-transform:uppercase;letter-spacing:.1em;margin-bottom:.4rem">'
                        'Billing</div>', unsafe_allow_html=True)
            stream_tv=st.selectbox("Streaming TV",["No","Yes","No internet service"])
            stream_mv=st.selectbox("Streaming Movies",["No","Yes","No internet service"])
            contract=st.selectbox("Contract",["Month-to-month","One year","Two year"])
            paperless=st.selectbox("Paperless Billing",["Yes","No"])
            payment=st.selectbox("Payment",["Electronic check","Mailed check",
                                             "Bank transfer (automatic)",
                                             "Credit card (automatic)"])
            monthly_c=st.number_input("Monthly Charges ($)",18.0,120.0,65.0,0.5)
            total_c=st.number_input("Total Charges ($)",0.0,9000.0,
                                     float(tenure*monthly_c),10.0)
        submitted=st.form_submit_button("🔮  Calculate Churn Risk",
                                        use_container_width=True)

    if submitted:
        inp={'Gender':gender,'Senior Citizen':senior,'Partner':partner,
             'Dependents':dependents,'Tenure Months':tenure,'Phone Service':phone,
             'Multiple Lines':multiline,'Internet Service':internet,
             'Online Security':online_sec,'Online Backup':online_bk,
             'Device Protection':dev_prot,'Tech Support':tech_sup,
             'Streaming TV':stream_tv,'Streaming Movies':stream_mv,
             'Contract':contract,'Paperless Billing':paperless,
             'Payment Method':payment,'Monthly Charges':monthly_c,
             'Total Charges':total_c}
        row=pd.DataFrame([inp])
        for col in row.select_dtypes(include='object').columns:
            if col in encs:
                le=encs[col]; v=str(row[col].iloc[0])
                row[col]=le.transform([v])[0] if v in le.classes_ else 0
            else: row[col]=0
        row=row.reindex(columns=X.columns,fill_value=0)
        lr_p=lr.predict_proba(sc.transform(row))[0][1]
        rf_p=rf.predict_proba(row)[0][1]
        avg_p=(lr_p+rf_p)/2

        if avg_p<.3:   risk,rclr,emoji,advice="LOW RISK",  GREEN, "✅","Customer shows strong retention signals."
        elif avg_p<.6: risk,rclr,emoji,advice="MEDIUM RISK",AMBER,"⚠️","Consider a personalised retention offer."
        else:          risk,rclr,emoji,advice="HIGH RISK",  PINK, "🚨","Immediate retention action recommended!"

        sec("Prediction Result")
        r1,r2=st.columns(2)
        with r1:
            st.markdown(f"""
            <div class="result-card" style="border-top:3px solid {rclr}">
                <div style="font-size:2.8rem;margin-bottom:.5rem">{emoji}</div>
                <div style="font-size:.65rem;color:{MUTED};text-transform:uppercase;
                             letter-spacing:.12em;font-weight:600;margin-bottom:.3rem">
                    Churn Risk</div>
                <div style="font-size:2rem;font-weight:800;color:{rclr}">{risk}</div>
                <div style="font-size:3.8rem;font-weight:800;color:{rclr};line-height:1.05;
                             font-family:'JetBrains Mono',monospace">{avg_p*100:.1f}%</div>
                <div style="font-size:.82rem;color:{MUTED};margin-top:.8rem;line-height:1.5">
                    {advice}</div>
                <div style="display:flex;gap:10px;margin-top:1.4rem">
                    <div style="flex:1;background:{BG3};border:1px solid {BORDER};
                                border-radius:11px;padding:11px;border-top:2px solid {BLUE}">
                        <div style="font-size:.6rem;color:{MUTED};font-weight:600;
                                     text-transform:uppercase">Logistic Reg</div>
                        <div style="font-size:1.35rem;font-weight:700;color:{BLUE};
                                     font-family:'JetBrains Mono',monospace;margin-top:3px">
                            {lr_p*100:.1f}%</div></div>
                    <div style="flex:1;background:{BG3};border:1px solid {BORDER};
                                border-radius:11px;padding:11px;border-top:2px solid {GREEN}">
                        <div style="font-size:.6rem;color:{MUTED};font-weight:600;
                                     text-transform:uppercase">Random Forest</div>
                        <div style="font-size:1.35rem;font-weight:700;color:{GREEN};
                                     font-family:'JetBrains Mono',monospace;margin-top:3px">
                            {rf_p*100:.1f}%</div></div>
                </div>
            </div>""", unsafe_allow_html=True)
        with r2:
            fig=go.Figure(go.Indicator(
                mode="gauge+number", value=avg_p*100,
                number=dict(suffix='%',font=dict(size=36,color=rclr,
                                                  family='JetBrains Mono')),
                gauge=dict(
                    axis=dict(range=[0,100],tickfont=dict(color=MUTED,size=11)),
                    bar=dict(color=rclr,thickness=.2),
                    bgcolor=BG2, bordercolor=BORDER, borderwidth=1,
                    steps=[dict(range=[0,30],color='#051a10'),
                           dict(range=[30,60],color='#1a1205'),
                           dict(range=[60,100],color='#1a0508')],
                    threshold=dict(line=dict(color=WHITE,width=2),
                                   thickness=.7,value=avg_p*100)),
                title=dict(text='Ensemble Probability',
                           font=dict(color=MUTED,size=13))))
            fig.update_layout(paper_bgcolor='rgba(0,0,0,0)',
                              height=300,margin=dict(t=50,b=10,l=20,r=20))
            st.plotly_chart(fig, use_container_width=True)

            fig2=go.Figure()
            for name,val,clr in [('LR',lr_p*100,BLUE),
                                   ('RF',rf_p*100,GREEN),
                                   ('Ensemble',avg_p*100,rclr)]:
                fig2.add_trace(go.Bar(x=[name],y=[val],marker_color=clr,
                                      showlegend=False,width=.5,
                                      marker_line_color=BG0,marker_line_width=1.5))
            fig2_layout = dict(
                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor=BG2,
                font=dict(color=MUTED,family='Space Grotesk',size=11),
                xaxis=dict(gridcolor=GRID,linecolor=BORDER,tickfont=dict(color=MUTED)),
                yaxis=dict(gridcolor=GRID,linecolor=BORDER,tickfont=dict(color=MUTED),
                           title=dict(text='Probability (%)',font=dict(color=MUTED))),
                margin=dict(l=8,r=8,t=36,b=8), height=200,
                title=dict(text='Model Breakdown',font=dict(color=WHITE,size=12),x=0)
            )
            fig2.update_layout(**fig2_layout)
            st.plotly_chart(fig2, use_container_width=True)
